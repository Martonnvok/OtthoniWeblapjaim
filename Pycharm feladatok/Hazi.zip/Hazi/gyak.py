
def osztalyzas():
    print("Legkisebbtől a legnagyobbig:")
    a = int(input("Kérlek adj meg egy számot:"))
    b = int(input("Kérlek adj még egy nagyobb számot:"))
    if a>b:
        for i in range(b, a):
         print(i)
    else:
        for i in range(a,b):
         print(i)
def osztalyzas2():
    print("Szorzatos(for):")
    a = int(input("Kérlek adj meg egy számot:"))
    b = int(input("Kérlek adj még egy nagyobb számot:"))
    ossz= int(a*b)
    if a > b:
        for i in range(ossz):
            print(i)
    else:
        for i in range(ossz):
            print(i)

def osztalyzas3():
    print("Szorzatos(while):")
    a = int(input("Kérlek adj meg egy számot:"))
    b = int(input("Kérlek adj még egy nagyobb számot:"))
    ossz= int(a*b)
    n=int(0);
    while(n != ossz):
        n+=1
        print(n)

def osztalyzas4():
    print()
    print("Utsó feladat, pozitív számok, végén leszedve a vessző:")
    for i in range(2,8):
        print( i, end= ",")
        if(i==7):
            print(8)

