import gyak
gyak.osztalyzas()
gyak.osztalyzas2()
gyak.osztalyzas3()
gyak.osztalyzas4()